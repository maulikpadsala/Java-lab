package com.example.java_midsem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public static final String _team1Name = "team1";
    public static final String _team2Name = "team2";

    private EditText editTextT1;
    private EditText editTextT2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextT1 = findViewById(R.id.editTextT1);
        editTextT2 = findViewById(R.id.editTextT2);

    }

    public void runSecondActivity(View view) {
        String team1Name = editTextT1.getText().toString();
        String team2Name = editTextT2.getText().toString();

        Intent intent = new Intent(this,ScoreActivity.class);
        intent.putExtra(_team1Name, team1Name);
        intent.putExtra(_team2Name, team2Name);

        startActivity(intent);


    }
}