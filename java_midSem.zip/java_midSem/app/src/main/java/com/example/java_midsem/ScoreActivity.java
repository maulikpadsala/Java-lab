package com.example.java_midsem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class ScoreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score); Intent intent = getIntent();

        String team1Name = intent.getStringExtra(MainActivity._team1Name);
        String team2Name = intent.getStringExtra(MainActivity._team2Name);

        TextView textViewT1 = findViewById(R.id.textViewT1);
        textViewT1.setText(team1Name);
        TextView textViewT2 = findViewById(R.id.textViewT2);
        textViewT2.setText(team2Name);

        Spinner spinnerGames = findViewById(R.id.spinner_games);
        TextView team1Score = findViewById(R.id.scoreT1);
        TextView team2Score = findViewById(R.id.scoreT2);

        Button team1Plus = findViewById(R.id.plusT1);
        Button team1Minus = findViewById(R.id.minusT1);


        Button team2Plus = findViewById(R.id.plusT2);
        Button team2Minus = findViewById(R.id.minusT2);

        team1Plus.setOnClickListener(new View.OnClickListener()
            {
            public void onClick(View v) {
                String game = spinnerGames.getSelectedItem().toString();
                int score  = Integer.parseInt(team1Score.getText().toString());
                if(game.equals("Cricket")){
                    score+=1;
                }
                else {
                    score+=5;
                }
                team1Score.setText(""+score);


            }
        });


        team1Minus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String game = spinnerGames.getSelectedItem().toString();
                int score  = Integer.parseInt(team1Score.getText().toString());
                if(game.equals("Cricket")){
                    score-=1;
                }
                else {
                    score-=5;
                }
                if (score < 0){
                    score = 0;
                    team1Score.setText(""+score);
                }else {
                    team1Score.setText(""+score);
                }



            }
        });


        team2Plus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String game = spinnerGames.getSelectedItem().toString();
                int score  = Integer.parseInt(team2Score.getText().toString());
                System.out.println(game);
                if(game.equals("Cricket")){
                    score+=1;
                }
                else {
                    score+=5;
                }
                team2Score.setText(""+score);


            }
        });



        team2Minus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String game = spinnerGames.getSelectedItem().toString();
                int score  = Integer.parseInt(team2Score.getText().toString());
                if(game.equals("Cricket")){
                    score-=1;
                }
                else {
                    score-=5;
                }
                if (score < 0){
                    score = 0;
                    team2Score.setText(""+score);
                }else {
                    team2Score.setText(""+score);
                }



            }
        });



    }

}